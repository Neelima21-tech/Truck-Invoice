sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/m/BusyDialog",
  "sap/m/MessageBox",
  "sap/ui/core/BusyIndicator",
  "sap/ui/model/Filter",
  "sap/ui/model/FilterOperator"

], (Controller, BusyDialog, MessageBox, BusyIndicator, Filter, FilterOperator) => {
  "use strict";

  return Controller.extend("com.wl.tm.truckinvoicemonitoring.controller.View1", {
    onInit() {
      var that = this;
      that.busy = new BusyDialog();
      var oJsonModel = new sap.ui.model.json.JSONModel([]);
			this.getView().setModel(oJsonModel, "chartData");
      this.apiCalling();
      //this.graphCallingTruck();
    },
    onChangeDate: function () {
      this.graphCallingTruck();
    },
    apiCalling: function () {
      var sAuthModel = this.getOwnerComponent().getModel("ZTM_BND_TRUCK_RAIL_AUTH");
      var user = sap.ushell.Container.getService("UserInfo").getId();
      //var user = "KKANCHAN";
      sap.ui.core.BusyIndicator.show();
      var aFilter = [];

      aFilter.push(new Filter({
        path: "edit",
        operator: FilterOperator.EQ,
        value1: "X"
      }));
      sAuthModel.read("/Auth",
     //sAuthModel.read("/Auth(vkorg='',usnam='" + user + "')",
        {
          filters: aFilter,

          success: function (oResponse) {
            this.getOwnerComponent().getModel("localModel").setProperty("/action", oResponse.results[0].status);
            sap.ui.core.BusyIndicator.hide();
          }.bind(this),
          error: function (oError) {
            sap.ui.core.BusyIndicator.hide();
            MessageBox.error(oError.message);
          }.bind(this)
        });
    },
    onChangeIconTab: function (oEvent) {
      if(oEvent.getParameter("key")==="graph"){
      this.graphCallingTruck();
      }
    },
    graphCallingTruck: function () {
      var oModel = this.getOwnerComponent().getModel();
      sap.ui.core.BusyIndicator.show();
      var aFilter = [];
      var sSelected;
      aFilter.push(new Filter({
        path: "date_sel",
        operator: FilterOperator.EQ,
        value1: this.getSelectedDate(this.getView().byId("dateSelectTruck").getSelectedKey())
      }));
      if(this.getView().byId("radioTruck").getSelectedIndex() === 0){sSelected="x"}
			else if(this.getView().byId("radioTruck").getSelectedIndex() === 1){sSelected=""}
			else if(this.getView().byId("radioTruck").getSelectedIndex() === 2){sSelected="y"}
      aFilter.push(new Filter({
        path: "By_Carr_prodtype",
        operator: FilterOperator.EQ,
        value1: sSelected
      }));
      
      oModel.read("/ZTM_CDS_I_TRKEDI_BAR_GRAPH",
        {
          urlParameters: {
            "$top": 10
          },
          filters: aFilter,
          success: function (oResponse) {
            var oJsonModel = this.getView().getModel("chartData");
						oJsonModel.setData(oResponse.results);
            var title;
						var graphTitle=this.getView().byId("radioTruck").getSelectedIndex();
						if(graphTitle===0){title="truck_graph_title";}
						else if(graphTitle===1){title="truck_graph_title_car";}
						else if(graphTitle===2){title="truck_graph_title_cc";}
						this._setAddGraphSettings(this.getView().byId("vizFrame"),title,"truck_cat_axis_lbl", "truck_legend_lbl");

            // oResponse.results.forEach(function (item) {
            //   item.value = parseInt(item.value);
            // });
            // this._renderChart1(oResponse.results);
            
            sap.ui.core.BusyIndicator.hide();
          }.bind(this),
          error: function (oError) {
            sap.ui.core.BusyIndicator.hide();
            MessageBox.error(oError.message);
          }.bind(this)
        });
    },
     //function to set the graph settings 
		_setAddGraphSettings: function (oVizFrame,sTitle,sCategoryAxisLbl,sLegendLbl) {
			//this.getView().getModel( "chartData").refresh(true); 
			var vizProperties = {
				interaction: {
					zoom: {
						enablement: "disabled"
					},
					selectability: {
						mode: "EXCLUSIVE"
					}
				},
				valueAxis: {
					title: {
						visible: true,
						text:"$"
					},
					visible: true,
					axisLine: {
						visible: true
					},
					label: {
						linesOfWrap: 2,
						visible: true,
						style: {
							fontSize: "10px"
						}
					}
				},
				categoryAxis: {
					title: {
						visible: true ,
						text:this.changei18n(sCategoryAxisLbl)
					},
					label: {
						linesOfWrap: 2,
						rotation: "fixed",
						angle: 0,
						style: {
							fontSize: "12px"
						}
					},
					axisTick: {
						shortTickVisible: false
					}
				},
				title: {
					text: this.changei18n(sTitle),
					visible: true
				},
				legend: {
					visible: true,
					title:{
						text:this.changei18n(sLegendLbl),
						visible:true
					}
				},
				plotArea: {
					colorPalette: ["#007181"],
					gridline: {
						visible: true
					},
					dataLabel: {
						visible: true,
						style: {
							fontWeight: 'bold'
						},
						hideWhenOverlap: false
					} 
				}
			};

			oVizFrame.setVizProperties(vizProperties);
		},
    getSelectedDate: function (key) {
      if (key === "0") { return "015"; }
      if (key === "1") { return "030"; }
      if (key === "2") { return "060"; }
      if (key === "3") { return "090"; }
      if (key === "4") { return "180"; }
      if (key === "5") { return "001"; }
    },

    _renderChart1: function (oData) {

      var oJsonModel = new sap.ui.model.json.JSONModel(oData);
      this.getView().setModel(oJsonModel, "ColumnChartData");

      var oVizFrame = this.getView().byId("vizFrame");
      oVizFrame.setModel(oJsonModel, "ColumnChartData");

      oVizFrame.setModel(oJsonModel, "chartData");
      oVizFrame.getVizProperties().categoryAxis.title.Text="Invoice Failure Count";

    },
    changei18n: function (sText, sPlaceholder) {
      var oResourceBundle = this.getOwnerComponent().getModel("i18n");
      var cText = oResourceBundle.getResourceBundle().getText(sText, sPlaceholder);
      return cText;
    },

    onSavePress: function () {
      var payload = [];
      var sTable = this.getView().byId("reportTable");
      var sIndex = this.getView().byId("reportTable").getSelectedIndex();
      if (sIndex === -1) {
        MessageBox.information("please select row");
        return;
      }
      // var sObject = sTable.getContextByIndex(sIndex).getObject()
      var sRow = this.getView().byId("reportTable").getSelectedIndices();
      sRow.forEach(index => {
        var sdata = sTable.getContextByIndex(index).getObject();
        var aCells = sTable.getRows()[index].getCells(),
          sUserNotes = "";
        aCells.forEach(cell => {
          if (cell && cell.mBindingInfos && cell.mBindingInfos.value && cell.mBindingInfos.value.binding && cell.mBindingInfos.value.binding.sPath === "UserNotes") {
            sUserNotes = cell.getValue();
            return;
          }
        });
        var sPayload = {
          //"CreatedOn" : sdata.CreatedOn !="" ? sap.ui.core.format.DateFormat.getDateTimeInstance({ pattern: "yyyyMMdd" }).format(new Date(sdata.CreatedOn)) : "",
          "CreatedOn": sdata.CreatedOn != "" ? this.formatDate(sdata.CreatedOn) : "",
          "FreightOrderNumber": sdata.FreightOrderNumber,
          "Delivery": sdata.Delivery,
          "UserNotes": sUserNotes,
          "ReviewedFlag" : aCells[9].mProperties.selected != false ? "X" :"",
        }
        payload.push(sPayload);
      });
      this.onPost(payload);
    },
    onPost: function (finalPayload) {
      var that = this;
      var oModel = this.getOwnerComponent().getModel();
      var aDeferredGroups = oModel.getDeferredGroups();
      if (!aDeferredGroups.includes("gid")) {
        aDeferredGroups = aDeferredGroups.concat(["gid"]);
        oModel.setDeferredGroups(aDeferredGroups);
      }

      that.busy.open();
      finalPayload.forEach(
        function (payload, idx) {
          oModel.create("/ZTM_CDS_I_TRK_IV_MON", payload, {
            groupId: "gid",
            success: function (oData, oHdr) {
            }.bind(this),
            error: function (oResponse, oHdr) {
            }.bind(this),
          });
        }.bind(this)
      );

      oModel.submitChanges({
        groupId: "gid",
        success: function (oData) {
          MessageBox.information("Successfull");
          that.busy.close();
        }.bind(this),
        error: function (oError) {
          MessageBox.error(oError.message);
          that.busy.close();
        }.bind(this),
      });
    },

    formatDate: function (oDate) {
      if (!oDate) {
        return oDate;
      }
      else {

        // var dateString = oDate.toISOString(); 
        // var dateObj = new Date(dateString);
        var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
          UTC: true,
          pattern: "yyyy-MM-dd\'T\'HH:mm:ss"

        });
        var formattedDate = oDateFormat.format(oDate);
        return formattedDate;
      }
    },
    onIgnore: function () {
      var payload = [];
      var sTable = this.getView().byId("reportTable");
      var sIndex = this.getView().byId("reportTable").getSelectedIndex();
      if (sIndex === -1) {
        MessageBox.information("please select row");
        return;
      }
      var sRow = this.getView().byId("reportTable").getSelectedIndices();
      sRow.forEach(index => {
        var sdata = sTable.getContextByIndex(index).getObject();
        var aCells = sTable.getRows()[index].getCells(),
          sUserNotes = "";
        aCells.forEach(cell => {
          if (cell && cell.mBindingInfos && cell.mBindingInfos.value && cell.mBindingInfos.value.binding && cell.mBindingInfos.value.binding.sPath === "UserNotes") {
            sUserNotes = cell.getValue();
            return;
          }
        });
        var sPayload = {
          //"CreatedOn" : sdata.CreatedOn !="" ? sap.ui.core.format.DateFormat.getDateTimeInstance({ pattern: "yyyyMMdd" }).format(new Date(sdata.CreatedOn)) : "",
          "CreatedOn": sdata.CreatedOn != "" ? this.formatDate(sdata.CreatedOn) : "",
          "FreightOrderNumber": sdata.FreightOrderNumber,
          "Delivery": sdata.Delivery,
          "UserNotes": sUserNotes,
          "ReviewedFlag" : aCells[9].mProperties.selected != false ? "X" :"",

        }
        payload.push(sPayload);
      });
      this.onIgnorePost(payload);
    },

    onIgnorePost: function (finalPayload) {
      var that = this;
      var oModel = this.getOwnerComponent().getModel();
      var aDeferredGroups = oModel.getDeferredGroups();
      if (!aDeferredGroups.includes("gid")) {
        aDeferredGroups = aDeferredGroups.concat(["gid"]);
        oModel.setDeferredGroups(aDeferredGroups);
      }

      that.busy.open();
      finalPayload.forEach(
        function (payload, idx) {
          oModel.create("/ZTM_CDS_I_TRUCK_EDI_IGNORE", payload, {
            groupId: "gid",
            success: function (oData, oHdr) {
            }.bind(this),
            error: function (oResponse, oHdr) {
            }.bind(this),
          });
        }.bind(this)
      );

      oModel.submitChanges({
        groupId: "gid",
        success: function (oData) {
          MessageBox.information("Successfull");
          that.busy.close();
        }.bind(this),
        error: function (oError) {
          MessageBox.error(oError.message);
          that.busy.close();
        }.bind(this),
      });
    },

    onClickDelivery: function (oEvent) {
      var sValue = oEvent.getSource().getProperty("text");
      var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
      var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
        target: {
          semanticObject: "OutboundDelivery",
          action: "displayInWebGUI"
        },
        params: {

          "OutboundDelivery": sValue
        }
      })) || ""; // generate the Hash
      var url = window.location.href.split('#')[0] + hash;
      sap.m.URLHelper.redirect(url, true);
    },
    // navigation for freight order number
    onClickFreightOrderNumber: function (oEvent) {
      var sValue = oEvent.getSource().getProperty("text");
      var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
      var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
        target: {
          semanticObject: "FreightOrder",
          action: "displayRoad"
        },
        params: {

          "FreightOrder": sValue
        }
      })) || ""; // generate the Hash
      var url = window.location.href.split('#')[0] + hash;
      sap.m.URLHelper.redirect(url, true);

    }
  });
});