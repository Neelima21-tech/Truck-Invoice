sap.ui.define([
	"comwltm/truck-invoice-monitoring/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
